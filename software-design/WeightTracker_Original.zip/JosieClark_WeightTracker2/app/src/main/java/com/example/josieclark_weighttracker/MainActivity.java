package com.example.josieclark_weighttracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.app.DatePickerDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.text.InputType;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.telephony.SmsManager;

import java.util.List;
import java.util.Locale;

import androidx.appcompat.app.AlertDialog;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper databasehelper;
    private long currentUserId = -1;
    private int currentScreen;
    private boolean smsEnabled = false;
    private String smsMessage = "SMS alerts are off.";

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (currentUserId == -1
                                || currentScreen != R.layout.activity_sms) {
                            return;
                        }

                        if (granted) {
                            saveSmsChoice(true);
                        } else {
                            saveSmsChoice(false);
                            smsMessage =
                                    "Permission denied. Weight tracking remains available.";
                            updateSmsStatus();
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        databasehelper = new DatabaseHelper(getApplicationContext());
        EdgeToEdge.enable(this);

        getOnBackPressedDispatcher().addCallback(
                this,
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        if (currentScreen == R.layout.activity_main) {
                            finish();
                        } else if (currentScreen == R.layout.activity_goal
                                || currentScreen == R.layout.activity_history) {
                            showLogin();
                        } else {
                            showHistory();
                        }
                    }
                });

        showLogin();
    }

    private void showScreen(int layout) {
        currentScreen = layout;
        setContentView(layout);

        View root = findViewById(R.id.main);

        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets safeArea = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.ime());

            view.setPadding(
                    safeArea.left,
                    safeArea.top,
                    safeArea.right,
                    safeArea.bottom);

            return insets;
        });

        ViewCompat.requestApplyInsets(root);
    }

    private void showLogin() {
        currentUserId = -1;
        showScreen(R.layout.activity_main);

        EditText usernameInput = findViewById(R.id.usernameInput);
        EditText passwordInput = findViewById(R.id.passwordInput);
        TextView loginError = findViewById(R.id.loginError);

        findViewById(R.id.signInButton).setOnClickListener(view -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString();

            loginError.setVisibility(View.GONE);

            if (username.isEmpty() || password.isEmpty()) {
                loginError.setText("Enter your username and password.");
                loginError.setVisibility(View.VISIBLE);
                return;
            }

            try {
                long userId = databasehelper.authenticate(username, password);

                if (userId == -1) {
                    loginError.setText("Incorrect username or password.");
                    loginError.setVisibility(View.VISIBLE);
                    return;
                }

                currentUserId = userId;
                passwordInput.setText("");

                // Accounts without a saved goal finish setup first.
                DatabaseHelper.UserSettings settings =
                        databasehelper.getSettings(currentUserId);

                if (settings.goal == null) {
                    showGoal();
                } else {
                    showHistory();
                }
            } catch (RuntimeException exception) {
                loginError.setText("Unable to sign in. Please try again.");
                loginError.setVisibility(View.VISIBLE);
            }
        });

        findViewById(R.id.createAccountButton).setOnClickListener(view -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString();

            loginError.setVisibility(View.GONE);

            if (username.isEmpty() || password.trim().isEmpty()) {
                loginError.setText("Enter a username and password to create an account.");
                loginError.setVisibility(View.VISIBLE);
                return;
            }

            if (password.length() < 8) {
                loginError.setText("Use a password with at least 8 characters.");
                loginError.setVisibility(View.VISIBLE);
                return;
            }

            try {
                if (databasehelper.usernameExists(username)) {
                    loginError.setText("That username is taken. Choose another or sign in.");
                    loginError.setVisibility(View.VISIBLE);
                    return;
                }

                long userId = databasehelper.createUser(username, password);

                if (userId == -1) {
                    loginError.setText("Unable to create the account. Try another username.");
                    loginError.setVisibility(View.VISIBLE);
                    return;
                }

                currentUserId = userId;
                passwordInput.setText("");

                Toast.makeText(
                        this,
                        "Account created. Set your weight goal next.",
                        Toast.LENGTH_SHORT
                ).show();

                showGoal();
            } catch (RuntimeException exception) {
                loginError.setText("Unable to create the account. Please try again.");
                loginError.setVisibility(View.VISIBLE);
            }
        });
    }
    private void showGoal() {
        if (currentUserId == -1) {
            showLogin();
            return;
        }

        showScreen(R.layout.activity_goal);

        EditText goalInput = findViewById(R.id.goalWeightInput);
        RadioGroup unitGroup = findViewById(R.id.unitGroup);
        RadioGroup directionGroup = findViewById(R.id.directionGroup);
        TextView goalError = findViewById(R.id.goalError);

        findViewById(R.id.saveGoalButton).setOnClickListener(view -> {
            goalError.setVisibility(View.GONE);

            String enteredGoal = goalInput.getText().toString().trim();
            double goal;

            try {
                goal = Double.parseDouble(enteredGoal);

                if (Double.isNaN(goal)
                        || Double.isInfinite(goal)
                        || goal <= 0) {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException exception) {
                goalError.setText("Enter a valid goal weight greater than zero.");
                goalError.setVisibility(View.VISIBLE);
                return;
            }

            String unit =
                    unitGroup.getCheckedRadioButtonId() == R.id.kilogramsOption
                            ? "kg" : "lb";

            int selectedDirection = directionGroup.getCheckedRadioButtonId();
            String direction;

            if (selectedDirection == R.id.gainOption) {
                direction = "gain";
            } else if (selectedDirection == R.id.maintainOption) {
                direction = "maintain";
            } else {
                direction = "lose";
            }

            try {
                boolean saved = databasehelper.saveGoal(
                        currentUserId, goal, unit, direction);

                if (!saved) {
                    goalError.setText("Unable to save your goal. Please try again.");
                    goalError.setVisibility(View.VISIBLE);
                    return;
                }

                Toast.makeText(
                        this,
                        "Goal saved.",
                        Toast.LENGTH_SHORT
                ).show();

                showHistory();
            } catch (RuntimeException exception) {
                goalError.setText("Unable to save your goal. Please try again.");
                goalError.setVisibility(View.VISIBLE);
            }
        });

        findViewById(R.id.goalBackButton)
                .setOnClickListener(view -> showLogin());
    }

    private void showHistory() {
        if (currentUserId == -1) {
            showLogin();
            return;
        }

        showScreen(R.layout.activity_history);

        TextView goalSummary = findViewById(R.id.goalSummary);
        TextView latestSummary = findViewById(R.id.latestWeightSummary);
        TextView emptyMessage = findViewById(R.id.emptyHistoryMessage);
        TableLayout weightTable = findViewById(R.id.weightTable);

        // Remove the fixed example rows while retaining the header.
        if (weightTable.getChildCount() > 1) {
            weightTable.removeViews(
                    1, weightTable.getChildCount() - 1);
        }

        // The example-entry caption sits immediately above the table.
        android.view.ViewGroup tableParent =
                (android.view.ViewGroup) weightTable.getParent();
        int tablePosition = tableParent.indexOfChild(weightTable);

        if (tablePosition > 0) {
            View caption = tableParent.getChildAt(tablePosition - 1);
            if (caption instanceof TextView) {
                ((TextView) caption).setText(
                        "Your saved daily weight entries.");
            }
        }

        try {
            DatabaseHelper.UserSettings settings =
                    databasehelper.getSettings(currentUserId);

            List<DatabaseHelper.WeightEntry> entries =
                    databasehelper.getWeights(currentUserId);

            if (settings.goal == null) {
                goalSummary.setText("Goal: Not set");
            } else {
                goalSummary.setText(String.format(
                        Locale.getDefault(),
                        "Goal: %.1f %s",
                        settings.goal,
                        settings.unit));
            }
            renderWeightRows(weightTable, entries, settings.unit);
            if (entries.isEmpty()) {
                latestSummary.setText("Latest weight: No entries yet");
                emptyMessage.setText(
                        "No weight entries yet. Tap Add Weight to begin.");
                emptyMessage.setVisibility(View.VISIBLE);
            } else {
                latestSummary.setText(String.format(
                        Locale.getDefault(),
                        "Latest weight: %.1f %s",
                        entries.get(0).weight,
                        settings.unit));

                emptyMessage.setVisibility(View.GONE);
            }
        } catch (RuntimeException exception) {
            latestSummary.setText("Unable to load weight history.");
            emptyMessage.setText(
                    "Please sign out and try signing in again.");
            emptyMessage.setVisibility(View.VISIBLE);
        }

        findViewById(R.id.addWeightButton)
                .setOnClickListener(view -> showAddWeight());

        findViewById(R.id.smsSettingsButton)
                .setOnClickListener(view -> showSms());

        findViewById(R.id.signOutButton)
                .setOnClickListener(view -> showLogin());
    }

    private void showAddWeight() {
        if (currentUserId == -1) {
            showLogin();
            return;
        }

        showScreen(R.layout.activity_add_weight);

        EditText weightInput = findViewById(R.id.dailyWeightInput);
        TextView dateText = findViewById(R.id.entryDateText);
        TextView unitText = findViewById(R.id.entryUnitText);
        TextView weightError = findViewById(R.id.weightError);

        DatabaseHelper.UserSettings settings =
                databasehelper.getSettings(currentUserId);

        unitText.setText("Weight unit: " + settings.unit);

        Calendar selectedDate = Calendar.getInstance();
        SimpleDateFormat storageFormat =
                new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        SimpleDateFormat displayFormat =
                new SimpleDateFormat("MM/dd/yyyy", Locale.US);

        dateText.setText(
                displayFormat.format(selectedDate.getTime())
                        + " (tap to change)");
        dateText.setMinHeight(dp(48));
        dateText.setContentDescription(
                "Entry date. Tap to choose a different date.");

        // Allow past entries so users can complete their history.
        dateText.setOnClickListener(view -> {
            DatePickerDialog picker = new DatePickerDialog(
                    this,
                    (datePicker, year, month, day) -> {
                        selectedDate.set(year, month, day);
                        dateText.setText(
                                displayFormat.format(selectedDate.getTime())
                                        + " (tap to change)");
                    },
                    selectedDate.get(Calendar.YEAR),
                    selectedDate.get(Calendar.MONTH),
                    selectedDate.get(Calendar.DAY_OF_MONTH));

            picker.getDatePicker().setMaxDate(
                    System.currentTimeMillis());
            picker.show();
        });

        findViewById(R.id.saveWeightButton).setOnClickListener(view -> {
            weightError.setVisibility(View.GONE);

            Double weight = parseWeight(
                    weightInput.getText().toString());

            if (weight == null) {
                weightError.setText(
                        "Enter a valid weight greater than zero.");
                weightError.setVisibility(View.VISIBLE);
                return;
            }

            String date = storageFormat.format(selectedDate.getTime());

            try {
                long entryId = databasehelper.addWeight(
                        currentUserId, date, weight);

                if (entryId == -1) {
                    weightError.setText(
                            "Could not save. If this date already has an "
                                    + "entry, edit it from Weight History.");
                    weightError.setVisibility(View.VISIBLE);
                    return;
                }

                Toast.makeText(
                        this, "Weight saved.", Toast.LENGTH_SHORT).show();
                checkGoalAlert(date, weight);
                showHistory();
            } catch (RuntimeException exception) {
                weightError.setText(
                        "Unable to save your weight. Please try again.");
                weightError.setVisibility(View.VISIBLE);
            }
        });

        findViewById(R.id.weightBackButton)
                .setOnClickListener(view -> showHistory());
    }

    private void showSms() {
        if (currentUserId == -1) {
            showLogin();
            return;
        }

        showScreen(R.layout.activity_sms);

        DatabaseHelper.UserSettings settings =
                databasehelper.getSettings(currentUserId);

        EditText phoneInput = findViewById(R.id.smsPhoneInput);
        phoneInput.setText(settings.phone);

        smsEnabled = settings.smsEnabled;
        smsMessage = smsEnabled
                ? "Goal alerts are enabled."
                : "Goal alerts are off.";
        updateSmsStatus();

        findViewById(R.id.enableSmsButton).setOnClickListener(view -> {
            String phone = phoneInput.getText().toString()
                    .trim().replaceAll("[\\s()\\-]", "");

            // Accept international numbers and short emulator numbers.
            if (!phone.matches("\\+?[0-9]{4,15}")) {
                phoneInput.setError(
                        "Enter a valid phone number, or 5554 for emulator testing.");
                return;
            }

            if (!getPackageManager().hasSystemFeature(
                    PackageManager.FEATURE_TELEPHONY)) {
                smsMessage =
                        "SMS is unavailable on this device. Weight tracking remains available.";
                updateSmsStatus();
                return;
            }

            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                saveSmsChoice(true);
            } else {
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        findViewById(R.id.skipSmsButton).setOnClickListener(view -> {
            if (saveSmsChoice(false)) {
                showHistory();
            }
        });

        findViewById(R.id.smsBackButton)
                .setOnClickListener(view -> showHistory());
    }

    private boolean saveSmsChoice(boolean enabled) {
        EditText phoneInput = findViewById(R.id.smsPhoneInput);
        String phone = phoneInput.getText().toString()
                .trim().replaceAll("[\\s()\\-]", "");

        if (enabled && !phone.matches("\\+?[0-9]{4,15}")) {
            phoneInput.setError("Enter a valid phone number.");
            return false;
        }

        try {
            boolean saved = databasehelper.saveSmsSettings(
                    currentUserId, enabled, phone);

            if (!saved) {
                smsMessage = "Unable to save SMS settings. Please try again.";
                updateSmsStatus();
                return false;
            }

            smsEnabled = enabled;
            smsMessage = enabled
                    ? "Goal alerts enabled. Tap Enable again to save a changed number."
                    : "Goal alerts are off. Weight tracking remains available.";
            updateSmsStatus();
            return true;
        } catch (RuntimeException exception) {
            smsMessage = "Unable to save SMS settings. Please try again.";
            updateSmsStatus();
            return false;
        }
    }

    private void updateSmsStatus() {
        if (currentScreen != R.layout.activity_sms) {
            return;
        }

        if (smsEnabled && ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            smsEnabled = false;
            smsMessage =
                    "SMS permission is unavailable. Tap Enable to request it again.";
        }

        TextView status = findViewById(R.id.smsStatusText);
        status.setText(smsMessage);
    }

    private Double parseWeight(String text) {
        try {
            double weight = Double.parseDouble(text.trim());

            if (Double.isNaN(weight)
                    || Double.isInfinite(weight)
                    || weight <= 0) {
                return null;
            }

            return weight;
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private int dp(int value) {
        return Math.round(
                value * getResources().getDisplayMetrics().density);
    }

    private String displayEntryDate(String storedDate) {
        try {
            SimpleDateFormat storageFormat =
                    new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            Date date = storageFormat.parse(storedDate);

            return date == null ? storedDate
                    : new SimpleDateFormat(
                    "MM/dd/yyyy", Locale.US).format(date);
        } catch (java.text.ParseException exception) {
            return storedDate;
        }
    }

    private TextView createTableText(String text, boolean header) {
        TextView cell = new TextView(this);
        cell.setText(text);
        cell.setTextSize(header ? 15 : 14);
        cell.setTextColor(Color.parseColor(
                header ? "#FFFFFF" : "#17324D"));
        cell.setPadding(dp(4), dp(8), dp(4), dp(8));

        cell.setLayoutParams(new TableRow.LayoutParams(
                0, TableRow.LayoutParams.WRAP_CONTENT, 1f));

        if (header) {
            cell.setTypeface(
                    null, android.graphics.Typeface.BOLD);
        }

        return cell;
    }

    private Button createEntryButton(String label, String color) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setBackgroundTintList(
                ColorStateList.valueOf(Color.parseColor(color)));
        button.setMinHeight(dp(48));
        button.setMinimumWidth(0);
        button.setMinWidth(0);

        button.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        return button;
    }

    private void renderWeightRows(
            TableLayout table,
            List<DatabaseHelper.WeightEntry> entries,
            String unit) {

        // Rebuild the grid with equal columns and aligned row actions.
        table.removeAllViews();
        table.setStretchAllColumns(true);
        table.setShrinkAllColumns(true);

        TableRow header = new TableRow(this);
        header.setBackgroundColor(Color.parseColor("#17324D"));
        header.addView(createTableText("Date", true));
        header.addView(createTableText("Weight", true));
        header.addView(createTableText("Actions", true));
        table.addView(header);

        for (int index = 0; index < entries.size(); index++) {
            DatabaseHelper.WeightEntry entry = entries.get(index);
            String date = displayEntryDate(entry.date);

            TableRow row = new TableRow(this);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setBackgroundColor(Color.parseColor(
                    index % 2 == 0 ? "#FFFFFF" : "#E8EFF3"));

            row.addView(createTableText(date, false));
            row.addView(createTableText(
                    String.format(Locale.getDefault(),
                            "%.1f %s", entry.weight, unit),
                    false));

            // Stack actions to keep them visible on narrow screens.
            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.VERTICAL);
            actions.setPadding(dp(2), dp(4), dp(2), dp(4));
            actions.setLayoutParams(new TableRow.LayoutParams(
                    0, TableRow.LayoutParams.WRAP_CONTENT, 1f));

            Button editButton = createEntryButton("Edit", "#256B70");
            editButton.setContentDescription(
                    "Edit weight entry for " + date);
            editButton.setOnClickListener(
                    view -> showEditWeight(entry, unit));

            Button deleteButton = createEntryButton(
                    "Delete", "#B3261E");
            deleteButton.setContentDescription(
                    "Delete weight entry for " + date);
            deleteButton.setOnClickListener(
                    view -> confirmDeleteWeight(entry));

            actions.addView(editButton);
            actions.addView(deleteButton);
            row.addView(actions);
            table.addView(row);
        }
    }

    private void showEditWeight(
            DatabaseHelper.WeightEntry entry, String unit) {

        EditText input = new EditText(this);
        input.setInputType(
                InputType.TYPE_CLASS_NUMBER
                        | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setSingleLine(true);
        input.setText(String.valueOf(entry.weight));
        input.setSelectAllOnFocus(true);
        input.setContentDescription("Updated weight in " + unit);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(24), dp(8), dp(24), dp(8));
        container.addView(input);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit weight (" + unit + ")")
                .setMessage(displayEntryDate(entry.date))
                .setView(container)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();

        // Keep the dialog open when validation or saving fails.
        dialog.setOnShowListener(ignored ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                        .setOnClickListener(view -> {
                            Double weight = parseWeight(
                                    input.getText().toString());

                            if (weight == null) {
                                input.setError(
                                        "Enter a weight greater than zero.");
                                return;
                            }

                            try {
                                boolean saved = databasehelper.updateWeight(
                                        currentUserId, entry.id, weight);

                                if (!saved) {
                                    input.setError(
                                            "Unable to update this entry.");
                                    return;
                                }

                                dialog.dismiss();
                                checkGoalAlert(entry.date, weight);
                                showHistory();
                            } catch (RuntimeException exception) {
                                input.setError(
                                        "Unable to save. Please try again.");
                            }
                        }));

        dialog.show();
    }

    private void confirmDeleteWeight(
            DatabaseHelper.WeightEntry entry) {

        new AlertDialog.Builder(this)
                .setTitle("Delete weight entry?")
                .setMessage(
                        "Remove the entry for "
                                + displayEntryDate(entry.date) + "?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> {
                    try {
                        boolean deleted = databasehelper.deleteWeight(
                                currentUserId, entry.id);

                        Toast.makeText(
                                this,
                                deleted ? "Entry deleted."
                                        : "Unable to delete this entry.",
                                Toast.LENGTH_SHORT).show();

                        showHistory();
                    } catch (RuntimeException exception) {
                        Toast.makeText(
                                this,
                                "Unable to delete. Please try again.",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }
    private void checkGoalAlert(String entryDate, double weight) {
        if (currentUserId == -1) {
            return;
        }

        String today = new SimpleDateFormat(
                "yyyy-MM-dd", Locale.US).format(new Date());

        // Adding historical measurements should not send current alerts.
        if (!today.equals(entryDate)) {
            return;
        }

        try {
            DatabaseHelper.UserSettings settings =
                    databasehelper.getSettings(currentUserId);

            if (settings.goal == null || !settings.smsEnabled
                    || settings.phone.isEmpty()) {
                return;
            }

            boolean goalReached;

            if ("gain".equals(settings.direction)) {
                goalReached = weight >= settings.goal;
            } else if ("maintain".equals(settings.direction)) {
                double tolerance = "kg".equals(settings.unit) ? 0.5 : 1.0;
                goalReached = Math.abs(weight - settings.goal) <= tolerance;
            } else {
                goalReached = weight <= settings.goal;
            }

            if (!goalReached) {
                return;
            }

            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED
                    || !getPackageManager().hasSystemFeature(
                    PackageManager.FEATURE_TELEPHONY)) {
                Toast.makeText(
                        this,
                        "Goal reached! SMS is unavailable; your weight is saved.",
                        Toast.LENGTH_LONG).show();
                return;
            }

            // Limit requests to one per day for each account and goal.
            String alertKey = "goal_alert_" + currentUserId;
            String signature = today + "|" + settings.goal
                    + "|" + settings.unit + "|" + settings.direction;

            android.content.SharedPreferences preferences =
                    getSharedPreferences("goal_alerts", MODE_PRIVATE);

            if (signature.equals(preferences.getString(alertKey, ""))) {
                return;
            }

            String message = String.format(
                    Locale.US,
                    "Weight Tracker: Goal reached! Today's weight: %.1f %s. Target: %.1f %s.",
                    weight, settings.unit, settings.goal, settings.unit);

            SmsManager manager;

            if (android.os.Build.VERSION.SDK_INT >= 31) {
                manager = getSystemService(SmsManager.class);
            } else {
                manager = SmsManager.getDefault();
            }

            if (manager == null) {
                throw new IllegalStateException("SMS service unavailable.");
            }

            manager.sendTextMessage(
                    settings.phone, null, message, null, null);

            preferences.edit().putString(alertKey, signature).apply();

            Toast.makeText(
                    this,
                    "Goal reached! SMS sending requested.",
                    Toast.LENGTH_LONG).show();

        } catch (RuntimeException exception) {
            // SMS failure must never undo or prevent a weight save.
            Toast.makeText(
                    this,
                    "Weight saved, but the goal SMS could not be requested.",
                    Toast.LENGTH_LONG).show();
        }
    }
    private void showDemoMessage() {
        Toast.makeText(
                this,
                "UI demonstration only. Database functions come in Project Three.",
                Toast.LENGTH_SHORT
        ).show();
    }
}