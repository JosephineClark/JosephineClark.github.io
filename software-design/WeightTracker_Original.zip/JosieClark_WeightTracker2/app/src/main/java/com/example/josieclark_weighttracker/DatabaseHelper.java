package com.example.josieclark_weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Each account owns its goal, preferences, and weight entries.
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL UNIQUE, " +
                "password_hash TEXT NOT NULL, " +
                "salt TEXT NOT NULL, " +
                "goal REAL, " +
                "unit TEXT NOT NULL DEFAULT 'lb', " +
                "direction TEXT NOT NULL DEFAULT 'lose', " +
                "sms_enabled INTEGER NOT NULL DEFAULT 0, " +
                "phone TEXT NOT NULL DEFAULT '')");

        db.execSQL("CREATE TABLE weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "entry_date TEXT NOT NULL, " +
                "weight REAL NOT NULL CHECK(weight > 0), " +
                "FOREIGN KEY(user_id) REFERENCES users(id) " +
                "ON DELETE CASCADE, " +
                "UNIQUE(user_id, entry_date))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 is the initial schema.
        // Future versions should migrate tables without deleting user data.
    }

    public boolean usernameExists(String username) {
        try (Cursor cursor = getReadableDatabase().query(
                "users", new String[]{"id"},
                "username = ?", new String[]{username},
                null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    public long createUser(String username, String password) {
        byte[] saltBytes = new byte[16];
        new SecureRandom().nextBytes(saltBytes);

        String salt = Base64.encodeToString(saltBytes, Base64.NO_WRAP);

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("salt", salt);
        values.put("password_hash", hashPassword(password, salt));

        // Returns -1 if the username already exists or insertion fails.
        return getWritableDatabase().insert("users", null, values);
    }

    public long authenticate(String username, String password) {
        try (Cursor cursor = getReadableDatabase().query(
                "users",
                new String[]{"id", "password_hash", "salt"},
                "username = ?", new String[]{username},
                null, null, null)) {

            if (!cursor.moveToFirst()) {
                return -1;
            }

            byte[] storedHash = Base64.decode(
                    cursor.getString(1), Base64.NO_WRAP);
            byte[] enteredHash = Base64.decode(
                    hashPassword(password, cursor.getString(2)),
                    Base64.NO_WRAP);

            return MessageDigest.isEqual(storedHash, enteredHash)
                    ? cursor.getLong(0) : -1;
        }
    }

    private String hashPassword(String password, String salt) {
        PBEKeySpec specification = new PBEKeySpec(
                password.toCharArray(),
                Base64.decode(salt, Base64.NO_WRAP),
                120000,
                256);

        try {
            byte[] hash = SecretKeyFactory
                    .getInstance("PBKDF2WithHmacSHA1")
                    .generateSecret(specification)
                    .getEncoded();

            return Base64.encodeToString(hash, Base64.NO_WRAP);
        } catch (Exception exception) {
            throw new IllegalStateException(
                    "Unable to process account password.", exception);
        } finally {
            specification.clearPassword();
        }
    }

    public UserSettings getSettings(long userId) {
        try (Cursor cursor = getReadableDatabase().query(
                "users",
                new String[]{"goal", "unit", "direction",
                        "sms_enabled", "phone"},
                "id = ?", new String[]{String.valueOf(userId)},
                null, null, null)) {

            if (!cursor.moveToFirst()) {
                throw new IllegalArgumentException("Account not found.");
            }

            UserSettings settings = new UserSettings();
            settings.goal = cursor.isNull(0) ? null : cursor.getDouble(0);
            settings.unit = cursor.getString(1);
            settings.direction = cursor.getString(2);
            settings.smsEnabled = cursor.getInt(3) == 1;
            settings.phone = cursor.getString(4);
            return settings;
        }
    }

    public boolean saveGoal(long userId, double goal,
                            String unit, String direction) {
        ContentValues values = new ContentValues();
        values.put("goal", goal);
        values.put("unit", unit);
        values.put("direction", direction);

        return getWritableDatabase().update(
                "users", values, "id = ?",
                new String[]{String.valueOf(userId)}) == 1;
    }

    public boolean saveSmsSettings(long userId,
                                   boolean enabled, String phone) {
        ContentValues values = new ContentValues();
        values.put("sms_enabled", enabled ? 1 : 0);
        values.put("phone", phone);

        return getWritableDatabase().update(
                "users", values, "id = ?",
                new String[]{String.valueOf(userId)}) == 1;
    }

    public long addWeight(long userId, String date, double weight) {
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("entry_date", date);
        values.put("weight", weight);

        // One daily entry per account; duplicates return -1.
        return getWritableDatabase().insert("weights", null, values);
    }

    public boolean updateWeight(long userId, long entryId, double weight) {
        ContentValues values = new ContentValues();
        values.put("weight", weight);

        // Account ownership is checked for every modification.
        return getWritableDatabase().update(
                "weights", values, "id = ? AND user_id = ?",
                new String[]{String.valueOf(entryId),
                        String.valueOf(userId)}) == 1;
    }

    public boolean deleteWeight(long userId, long entryId) {
        return getWritableDatabase().delete(
                "weights", "id = ? AND user_id = ?",
                new String[]{String.valueOf(entryId),
                        String.valueOf(userId)}) == 1;
    }

    public List<WeightEntry> getWeights(long userId) {
        List<WeightEntry> entries = new ArrayList<>();

        // Dates will be stored as yyyy-MM-dd so they sort correctly.
        try (Cursor cursor = getReadableDatabase().query(
                "weights", new String[]{"id", "entry_date", "weight"},
                "user_id = ?", new String[]{String.valueOf(userId)},
                null, null, "entry_date DESC, id DESC")) {

            while (cursor.moveToNext()) {
                entries.add(new WeightEntry(
                        cursor.getLong(0),
                        cursor.getString(1),
                        cursor.getDouble(2)));
            }
        }

        return entries;
    }

    public static class UserSettings {
        public Double goal;
        public String unit;
        public String direction;
        public boolean smsEnabled;
        public String phone;
    }

    public static class WeightEntry {
        public final long id;
        public final String date;
        public final double weight;

        public WeightEntry(long id, String date, double weight) {
            this.id = id;
            this.date = date;
            this.weight = weight;
        }
    }
}